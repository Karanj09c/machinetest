<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Model\\App\\Providers\\ModelServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Model\\App\\Providers\\ModelServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);