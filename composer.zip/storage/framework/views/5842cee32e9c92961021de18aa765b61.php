
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1> All Doctors </h1>
                </div>
            </div>
            <div class="all_user_title">
            
            </div>
        </div>
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <?php if(Session::has('success_message')): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <strong>Success:</strong> <?php echo e(Session::get('success_message')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                            <h3 class="card-title nofloat"> <span> All Doctors</span>
                                <span> 
                                    <a href="<?php echo e(url('admin/doctors/create')); ?>"> 
                                        <button type="button" class="btn btn-block btn-primary">Add a New Doctor</button> 
                                    </a> 
                                </span>
                            </h3>
                        </div>
                        <div class="card-body">
                            <div id="free" class="tabcontent">
                                <table id="example2" class="table tables table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>S.No.</th>
                                            <th>Name</th>
                                            <th>Spaciality</th>
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($value->doctor_name); ?></td>
                                                <td><?php echo e($value->doctor_speciality); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin::layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doctor\Modules/Admin\resources/views/doctors/index.blade.php ENDPATH**/ ?>