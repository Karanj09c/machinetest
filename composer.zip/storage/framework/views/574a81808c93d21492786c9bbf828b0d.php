
<h2><?php echo e($doctor->name); ?></h2>
<form method="POST" action="<?php echo e(route('appointments.store')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="doctor_id" value="<?php echo e($doctor->id); ?>">
    <input type="date" name="date" required>
    <select name="time_slot" required>
        <option value="09:00">9:00 AM</option>
        <option value="10:00">10:00 AM</option>
        <!-- Add more time slots here -->
    </select>
    <button type="submit">Book Appointment</button>
</form>
<?php /**PATH C:\xampp\htdocs\doctor\resources\views/doctor/show.blade.php ENDPATH**/ ?>